# LLM代理服务 - Termux服务配置指南

## 概述
本配置允许LLM代理服务在Android的Termux环境中以服务形式运行，支持开机自启和日志管理。

## 文件结构
```
termux-services/
├── llm-proxy-daemon          # 服务启动脚本
├── llm-proxy.service         # Termux服务配置文件
├── log-manager.sh            # 日志管理工具
├── setup-termux-service.sh   # 自动安装配置脚本
└── README.md                 # 本说明文档
```

## 快速开始

### 方法1：自动安装（推荐）
1. 复制项目到Termux
2. 运行自动配置脚本：
   ```bash
   cd LLM代理服务_Web版/termux-services
   bash setup-termux-service.sh
   ```

### 方法2：手动安装
1. **安装必要软件包**：
   ```bash
   pkg update && pkg install termux-services python curl procps net-tools
   ```

2. **配置服务目录**：
   ```bash
   mkdir -p ~/.termux/service/llm-proxy
   ```

3. **复制服务文件**：
   ```bash
   cp llm-proxy-daemon ~/.termux/service/llm-proxy/
   chmod +x ~/.termux/service/llm-proxy/llm-proxy-daemon
   cp llm-proxy.service ~/.termux/service/
   ```

4. **创建日志目录**：
   ```bash
   mkdir -p ~/.llm-proxy/logs
   ```

5. **安装Python依赖**：
   ```bash
   pip install -r ../requirements.txt
   ```

6. **启用服务**：
   ```bash
   sv up llm-proxy
   ```

## 服务管理命令

### 基本命令
```bash
# 启动服务
sv up llm-proxy

# 停止服务
sv down llm-proxy

# 重启服务
sv restart llm-proxy

# 查看服务状态
sv status llm-proxy
```

### 日志管理
使用提供的日志管理工具：
```bash
# 查看最近50行日志
./log-manager.sh view

# 查看指定行数日志
./log-manager.sh view 100

# 清理所有日志
./log-manager.sh clean

# 查看服务状态
./log-manager.sh status

# 显示帮助
./log-manager.sh help
```

### 手动查看日志
```bash
# 实时查看日志
tail -f ~/.llm-proxy/logs/llm-proxy.log

# 查看错误日志
tail -f ~/.llm-proxy/logs/llm-proxy-error.log
```

## 开机自启配置

### 自动配置
运行 `setup-termux-service.sh` 会自动配置开机自启。

### 手动配置
1. 创建启动脚本：
   ```bash
   mkdir -p ~/.termux/boot
   cat > ~/.termux/boot/llm-proxy-boot << 'EOF'
   #!/data/data/com.termux/files/usr/bin/bash
   sleep 5
   sv up llm-proxy
   EOF
   chmod +x ~/.termux/boot/llm-proxy-boot
   ```

## 配置文件

### 服务配置
服务配置文件位于 `~/.termux/service/llm-proxy.service`，可以修改：
- 启动命令
- 重启策略
- 用户权限

### 应用配置
应用配置文件位于项目根目录的 `config.ini`，包含：
- 服务器端口和地址
- API密钥配置
- 请求超时设置

## 故障排除

### 服务无法启动
1. **检查日志**：
   ```bash
   ./log-manager.sh view 100
   ```

2. **检查端口占用**：
   ```bash
   netstat -tuln | grep :8080
   ```

3. **检查Python环境**：
   ```bash
   python --version
   pip list | grep -E "(fastapi|uvicorn|httpx)"
   ```

### 端口冲突
如果8080端口被占用，修改 `config.ini` 中的端口配置：
```ini
[SERVER]
port = 8081
```

### 权限问题
确保所有脚本有执行权限：
```bash
chmod +x ~/.termux/service/llm-proxy/llm-proxy-daemon
chmod +x termux-services/log-manager.sh
```

## 性能优化

### 内存优化
对于内存较小的设备，可以：
1. 减少API密钥数量
2. 降低 `min_response_length` 值
3. 减少 `request_timeout` 时间

### 日志优化
定期清理日志文件：
```bash
./log-manager.sh clean
```

## 网络配置

### 局域网访问
修改 `config.ini` 允许局域网访问：
```ini
[SERVER]
host = 0.0.0.0
```

### 防火墙配置
确保Termux有网络访问权限，在Android设置中允许Termux的网络访问。

## 更新和维护

### 更新服务
1. 停止服务：
   ```bash
   sv down llm-proxy
   ```

2. 更新代码：
   ```bash
   git pull  # 如果使用git
   ```

3. 重启服务：
   ```bash
   sv up llm-proxy
   ```

### 备份配置
定期备份配置文件：
```bash
cp config.ini config.ini.backup
```

## 卸载服务

### 完全卸载
```bash
# 停止服务
sv down llm-proxy

# 删除服务文件
rm -rf ~/.termux/service/llm-proxy
rm ~/.termux/service/llm-proxy.service

# 删除开机启动
rm ~/.termux/boot/llm-proxy-boot

# 删除日志
rm -rf ~/.llm-proxy
```

## 技术支持

如有问题，请检查：
1. 日志文件中的错误信息
2. 确保所有依赖已正确安装
3. 检查网络连接和API密钥有效性